#!/bin/bash

bash ${BASH_SOURCE%/*}/debian/postinst "$@"
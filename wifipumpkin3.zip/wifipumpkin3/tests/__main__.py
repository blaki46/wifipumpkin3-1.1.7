#!/usr/bin/env python3.7

import unittest

if __name__ == "__main__":  # pragma: no cover
    unittest.main(module="tests", verbosity=2)
